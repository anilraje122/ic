import React, {Component} from 'react';

class Footer extends Component {
    render() {
        return  <div id="footer">
                <p>Copyright &copy; Anil Raj 2020 All Rights Reserved</p>
            </div>
    }
}

export default Footer;